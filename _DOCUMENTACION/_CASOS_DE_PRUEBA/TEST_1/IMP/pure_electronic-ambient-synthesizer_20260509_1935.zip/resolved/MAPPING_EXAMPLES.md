# Node Type → Target Language Mapping Examples

This document provides **concrete, minimal code snippets** for each PIM node type,
mapped to the four supported audio synthesis target languages.
Use these as few-shot references when generating the full synthesis program.

---

## Legend

Each example shows the **minimum instantiation** for a node with representative parameters.
Replace the parameter values with those from `initialValue` in the actual model.

---


---

## 1. `oscillator` — Waveform Generator




### Pure Data
```pd
[osc~ 440]            // sine generator
[phasor~ 440]         // sawtooth/ramp generator (0 to 1)

// Para otras formas de onda se suelen usar tablas [table] o 
// manipular [phasor~] con [expr~] o [cos~]
```

---

## 2. `noise` — Noise Generator




### Pure Data
```pd
[noise~]   // White noise generator
```

---

## 3. `sample` — Audio File Playback




### Pure Data
```pd
[readsf~ 1]          // Streaming mono
[soundfiler]         // Para cargar en un array/table
[tabplay~ myTable]   // Reproducción desde tabla
```

---

## 4. `envelope` — ADSR/AR Envelope Generator




### Pure Data
```pd
[vline~]               // Generador de rampas precisas
// Mensaje: [1 10, 0.7 100 10, 0 300 500( -> [vline~]
// (valor tiempo retardo)
```

---

## 5. `frequency_filter` — Filter Node




### Pure Data
```pd
[lop~ 1000]            // Simple LPF
[hip~ 1000]            // Simple HPF
[bp~ 1000 10]          // Bandpass (freq, Q)
[vcf~]                 // Voltage Controlled Filter (con entrada de señal para freq)
```

---

## 6. `gain_pan` — Level and Stereo Panning




### Pure Data
```pd
[*~ 0.5]    // Gain
[pan~]      // De la librería cyclone
// Manual: entrada -> [*~ left_vol] -> dac~ 1
//         entrada -> [*~ right_vol] -> dac~ 2
```

---

## 7. `mixer` — Audio Summing (Up to 10 inputs)




### Pure Data
```pd
[+~] // Suma de señales.
```

---

## 8. `delay` — Echo/Delay Line




### Pure Data
```pd
[delwrite~ myDelay 1000] // Buffer
[delread~ myDelay 500]   // Lectura fija
[vd~ myDelay]            // Lectura variable (para chorus/flanger)
```

---

## 9. `reverb` — Reverberation




### Pure Data
```pd
[freeverb~] // Reverberación clásica
```

---

## Appendix: File Syntax for Visual Languages

If the target is a visual language, use the following syntax to generate the actual file content.

### Pure Data (.pd) Syntax
A Pure Data file is a plain text file. Use this structure to encapsulate a PIM Machine:

```pd
#N canvas 0 0 450 300 10;
#X obj 50 50 inlet~;
#X obj 50 100 osc~ 440;
#X obj 50 150 *~ 0.5;
#X obj 50 200 outlet~;
#X connect 0 0 1 0;
#X connect 1 0 2 0;
#X connect 2 0 3 0;
```
*Note: `#N canvas` defines the window. `#X obj X Y name args` defines objects. `#X connect sourceNode sourceOutlet targetNode targetInlet` defines wires.*

