# Consolidated DSL Reference Manuals

This file contains all the technical rules and grammar definitions for the MDA-Audio system.

## File: cim-machines.md

# @schema MDA-Audio-CIM-Machine (Computational Independence Model)
# @context Synthesis Design Intent (Abstract DSP structure for Max/MSP, PureData, Web Audio)

Technical specification for high-level audio machine topology. CIM nodes define functional intent without implementation constraints.

## @object Document (Root)
| Property | Type | Constraints | @mapping |
| :--- | :--- | :--- | :--- |
| `id` | UUIDv4 | Exact 36 chars | Global Machine Unique ID |
| `name` | String | [1, 20] chars | Machine display name |
| `description` | String | [10, 600] chars | Functional purpose |
| `elements` | Array[Element] | | List of internal functional blocks |

## @object Element (Functional Block)
| Property | Type | Constraints | @mapping |
| :--- | :--- | :--- | :--- |
| `id` | UUIDv4 | Exact 36 chars | Component instance ID |
| `name` | String | [1, 20] chars | Block name |
| `description` | String | [10, 600] chars | Block DSP function |
| `params` | String | [10, 600] chars | Conceptual parameters (e.g., "Freq, Cutoff") |
| `externalOutput` | Object | @see ExternalConfig | Output port to project bus |
| `externalInput` | Object | @see ExternalConfig | Input port from project bus |
| `sendTo` | Array[SendTo] | | Internal directional signal routing |

### @fragment ExternalConfig
- `hasExternalOutput`/`Input` (Boolean): Enables global project-level connectivity.
- `description` (String): Port metadata. Max 600 chars.

## @object SendTo (Internal Routing)
Directional signal link between elements within the same machine.
- `id` (UUIDv4): Required.
- `idRef` (Reference): Must match an `id` of an `Element` in the same scope.
- `description` (String): [10, 600] chars.

### @constraint Semantic_Rules
- `@Rule_NoSelfReference`: `Element.id` != `SendTo.idRef`. Compiler rejects self-loops.
- `@Rule_IdUniqueness`: All `id` fields in document must be globally unique.

## @semantic_mapping
Use this document to map abstract synthesis intent to logical blocks. Fields like `params` define what the machine *can* do, while `sendTo` defines the *signal flow architecture*.


---

## File: cim-relations-machines.md

# @schema MDA-Audio-CIM-Relations (Computational Independence Model)
# @context High-Level Signal Routing (Project-wide Inter-Machine communication)

Orchestrates communication between independent `CIM-Machine` instances at project scale. Defines the global signal bus.

## @object Document (Root)
| Property | Type | Constraints | @mapping |
| :--- | :--- | :--- | :--- |
| `description` | String | [1, 1000] chars | Inter-machine network purpose |
| `relations` | Array[Relation] | | Set of global interconnections |

## @object Relation (Inter-Machine Link)
| Property | Type | Constraints | @mapping |
| :--- | :--- | :--- | :--- |
| `id` | UUIDv4 | Exact 36 chars | Relation unique identifier |
| `source` | UUIDv4 | Exact 36 chars | Source CIM Machine ID |
| `destination` | UUIDv4 | Exact 36 chars | Destination CIM Machine ID |
| `description` | String | [10, 1000] chars | DSP Bus justification |

### @constraint Validation_Rules
- `@Rule_Existence`: `source` and `destination` IDs must resolve to existing CIM machines in project scope.
- `@Rule_Disjointness`: `source` != `destination`. No feedback loops at CIM level.
- `@Rule_InterfaceSource`: Source machine MUST have at least one element with `externalOutput: true`.
- `@Rule_InterfaceDest`: Destination machine MUST have at least one element with `externalInput: true`.

## @semantic_mapping
This document defines the **Project Signal Topology**. Use it to determine which machines act as Synthesis Sources (Oscillators/Samplers) and which act as Processing/Output sinks (Filters/Mixers) at a conceptual level.


---

## File: pim-machines.md

# @schema MDA-Audio-PIM-Machine (Platform Independence Model)
# @context DSP Node Specification (Implementation-ready Synthesis for PD, Max, Web Audio)

Technical concretization of CIM models into implementable nodes. Defines specific synthesis algorithms, signal types, and parameter modifiability.

## @object Model (Root)
| Property | Type | Constraints | @mapping |
| :--- | :--- | :--- | :--- |
| `id` | UUIDv4 | 36 chars | PIM Machine Unique ID |
| `name` | String | Max 20 chars | Project-level display name |
| `ids_cim_reference`| Array[UUIDv4]| Required | Universe of CIM items implemented |
| `nodes` | Array[Node] | | Instances of DSP functional blocks |
| `edges` | Array[Edge] | | Direct signal/control connections |

## @interface Node (Base DSP Node)
Common structure for Generators, Modifiers, and Effects.
- `id` (UUIDv4): Unique instance identifier.
- `ids_references` (Array[UUIDv4]): Links to corresponding CIM elements.
- `others` (Array[OthersParameter]): Custom dynamic parameters.

### @type Parameter (DSP Property)
| Field | Type | Description | @constraint |
| :--- | :--- | :--- | :--- |
| `initialValue` | any | Default state | |
| `isModifiable` | Boolean | Signal modulation allowed | If false, reject incoming Control Edges |
| `isExternalInput` | Boolean | Expose to project bus | Must be false if `isModifiable` is false |

### @type ConnectionPoint (I/O Port)
- `isExternalInput`/`Output` (Boolean): Defines visibility for `PIM-Relations`.

## @object Edge (Signal Connection)
| Property | Description |
| :--- | :--- |
| `sourceNode` | UUID del nodo de origen. |
| `sourceParam`| Nombre de la propiedad/puerto de salida del nodo origen (ej: `output_1`). |
| `targetNode` | UUID del nodo de destino. |
| `targetParam`| Nombre de la propiedad/puerto de entrada del nodo destino (ej: `input_1`, `cutoff`). |
| `type` | Tipo de señal: `"audio"` o `"modification"`. |

## @dictionary Node_Definitions

### 1. Audio Generators (@category Source)
Produces PCM audio. Structural parameter `stereo` (Boolean) determines if `output_2` exists.
- **Oscillator**: Params: `waveform` (sine|sq|saw|tri|pulse|matrix), `frequency` (Hz), `pulseWidth`, `gain`, `phase`, `pan`.
- **Noise**: Params: `noiseType` (white|pink|brown), `gain`, `pan`.
- **Sample**: Params: `file` (Path), `loop` (Boolean), `gain`.

### 2. Parameter Modifiers (@category Control)
Produces modulation signals (typically 0-1 or Hz).
- **LFO**: Params: `waveform`, `rate` (Hz), `amplitude`, `sync` (Boolean).
- **Envelope**: Params: `envelopeType` (ADSR|ADR|AR|DAHDSR), `attack`, `decay`, `sustain`, `release`, `curve` (lin|exp|log).

### 3. Sound Modifiers (@category Effect)
Processes incoming audio. `stereo` determines `input_2`/`output_2` existence.
- **Filter**: `filterType` (LPF|HPF|BPF|Notch), `cutoff` (20-20k), `resonance` (Q), `slope`.
- **Reverb**: `roomSize`, `damping`, `decayTime`, `dryWet`.
- **Delay**: `delayTime`, `feedback`, `dryWet`.
- **Comp/Gain**: `gain`, `pan`, `threshold`, `ratio`.

### 4. Utilities (@category Summing)
- **Mixer**: Sums 2-10 signals via dynamic `input_1..10`.

## @semantic_mapping
This document is the **Synthesizer Implementation Blueprints**. Each node type maps directly to a DSP object in environments like PureData or Max/MSP. Connections of type `audio` are high-rate PCM streams, while `modification` are control-rate values (e.g., k-rate in Csound).


---

## File: pim-relations-machines.md

# @schema MDA-Audio-PIM-Relations (Platform Independence Model)
# @context Fine-Grained DSP Routing (Inter-Machine Parameter Modulation)

Detailed technical orchestration between PIM machines. Establish direct modulation links between ports and parameters across machine boundaries.

## @object Document (Root)
| Property | Type | Constraints | @mapping |
| :--- | :--- | :--- | :--- |
| `description` | String | Max 600 chars | Network modulation goal |
| `relations` | Array[Relation] | | Set of cross-machine DSP links |

## @object Relation (Technical Link)
| Property | Type | Constraints | @mapping |
| :--- | :--- | :--- | :--- |
| `id` | UUIDv4 | Exact 36 chars | Relation ID |
| `source` | UUIDv4 | Reference to Output Port | Must have `isExternalOutput: true` |
| `destination`| UUIDv4 | Reference to Input/Param | Must have `isExternalInput: true` |
| `description` | String | [10, 300] chars | Control/Audio flow purpose |

### @constraint Integrity_Rules
- `@Rule_PortValidation`: `source` must be a valid port ID in one of the project's PIM machines.
- `@Rule_DestValidation`: `destination` must be a valid port or parameter ID in a *different* PIM machine instance.
- `@Rule_Visibility`: Connections only allowed if the PIM machine's internal design explicitly exposes the port (external flags).

## @semantic_mapping
This document is the **Global DSP Patchbay**. It maps how a specific signal (e.g., LFO Output) from Machine A modulates a specific parameter (e.g., Filter Cutoff) in Machine B. This document provides the final routing table for the synthesizer runtime.


---

